import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { LaunchCard } from "../components/LaunchCard";
import { Button } from "../components/ui/button";
import { Calendar, Filter } from "lucide-react";
import { useState } from "react";

export function Launches() {
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const launches = [
    {
      vehicle: "LVM3-M4",
      mission: "Chandrayaan-3",
      date: "July 14, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "Chandrayaan-3 Spacecraft (3,900 kg)",
    },
    {
      vehicle: "PSLV-C57",
      mission: "Aditya-L1",
      date: "September 2, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "Aditya-L1 Solar Observatory (1,475 kg)",
    },
    {
      vehicle: "PSLV-C56",
      mission: "DS-SAR & 6 Co-passengers",
      date: "May 30, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "DS-SAR Satellite + 6 Satellites",
    },
    {
      vehicle: "SSLV-D2",
      mission: "EOS-07, Janus-1 & AzaadiSAT-2",
      date: "February 10, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "EOS-07 + 2 Co-passenger Satellites",
    },
    {
      vehicle: "PSLV-C55",
      mission: "TeLEOS-2 & Lumelite-4",
      date: "April 22, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "TeLEOS-2 + Lumelite-4",
    },
    {
      vehicle: "LVM3-M3",
      mission: "OneWeb India-2",
      date: "March 26, 2023",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "36 OneWeb Satellites",
    },
    {
      vehicle: "PSLV-C54",
      mission: "EOS-06 & 8 Nanosatellites",
      date: "November 26, 2022",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "EOS-06 Oceansat + 8 Nanosatellites",
    },
    {
      vehicle: "LVM3-M2",
      mission: "OneWeb India-1",
      date: "October 23, 2022",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "36 OneWeb Satellites",
    },
    {
      vehicle: "PSLV-C53",
      mission: "DS-EO & 2 Nanosatellites",
      date: "June 30, 2022",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Success" as const,
      payload: "DS-EO + 2 Nanosatellites",
    },
    {
      vehicle: "GSLV-F12",
      mission: "Gaganyaan Test Vehicle-D1",
      date: "Scheduled 2024",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Scheduled" as const,
      payload: "Crew Module Atmospheric Re-entry Experiment",
    },
    {
      vehicle: "PSLV-C58",
      mission: "XPoSat",
      date: "Scheduled 2024",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Scheduled" as const,
      payload: "X-ray Polarimeter Satellite",
    },
    {
      vehicle: "LVM3-M5",
      mission: "Gaganyaan Uncrewed Mission-1",
      date: "Scheduled 2024-2025",
      location: "Satish Dhawan Space Centre, Sriharikota",
      status: "Scheduled" as const,
      payload: "Gaganyaan Orbital Module (Uncrewed)",
    },
  ];

  const filteredLaunches =
    filterStatus === "all"
      ? launches
      : launches.filter((launch) => launch.status.toLowerCase() === filterStatus);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white py-20 relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-4">
            <Calendar className="w-12 h-12" />
            <h1 className="text-5xl font-bold">Launch Schedule</h1>
          </div>
          <p className="text-xl text-orange-100">
            Track ISRO's past and upcoming rocket launches
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="bg-white border-b border-gray-200 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-600" />
              <span className="font-medium text-gray-700">Filter by Status:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant={filterStatus === "all" ? "default" : "outline"}
                onClick={() => setFilterStatus("all")}
                className={
                  filterStatus === "all"
                    ? "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                    : "hover:bg-gray-100"
                }
              >
                All Launches
              </Button>
              <Button
                variant={filterStatus === "success" ? "default" : "outline"}
                onClick={() => setFilterStatus("success")}
                className={
                  filterStatus === "success"
                    ? "bg-green-600 hover:bg-green-700"
                    : "hover:bg-gray-100"
                }
              >
                Successful
              </Button>
              <Button
                variant={filterStatus === "scheduled" ? "default" : "outline"}
                onClick={() => setFilterStatus("scheduled")}
                className={
                  filterStatus === "scheduled"
                    ? "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700"
                    : "hover:bg-gray-100"
                }
              >
                Scheduled
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Launches Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <p className="text-gray-600">
              Showing <span className="font-semibold">{filteredLaunches.length}</span> launches
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredLaunches.map((launch, index) => (
              <LaunchCard key={index} {...launch} />
            ))}
          </div>
        </div>
      </section>

      {/* Launch Vehicles Info */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Our Launch Vehicles
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl">
              <h3 className="text-2xl font-bold text-blue-900 mb-3">PSLV</h3>
              <p className="text-gray-700 mb-4">
                Polar Satellite Launch Vehicle - ISRO's workhorse with over 50 successful missions
              </p>
              <div className="space-y-2 text-sm text-gray-700">
                <p>
                  <strong>Payload:</strong> Up to 1,750 kg to SSO
                </p>
                <p>
                  <strong>Height:</strong> 44 meters
                </p>
                <p>
                  <strong>Success Rate:</strong> 95%+
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl">
              <h3 className="text-2xl font-bold text-green-900 mb-3">LVM3</h3>
              <p className="text-gray-700 mb-4">
                Launch Vehicle Mark-3 - India's heaviest launch vehicle for complex missions
              </p>
              <div className="space-y-2 text-sm text-gray-700">
                <p>
                  <strong>Payload:</strong> Up to 8,000 kg to LEO
                </p>
                <p>
                  <strong>Height:</strong> 43.43 meters
                </p>
                <p>
                  <strong>Success Rate:</strong> 100%
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl">
              <h3 className="text-2xl font-bold text-purple-900 mb-3">SSLV</h3>
              <p className="text-gray-700 mb-4">
                Small Satellite Launch Vehicle - Quick turnaround launch vehicle for small satellites
              </p>
              <div className="space-y-2 text-sm text-gray-700">
                <p>
                  <strong>Payload:</strong> Up to 500 kg to LEO
                </p>
                <p>
                  <strong>Height:</strong> 34 meters
                </p>
                <p>
                  <strong>Turnaround:</strong> 72 hours
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}