import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import {
  Rocket,
  Target,
  Users,
  Trophy,
  Building2,
  Globe,
  Lightbulb,
  Heart,
} from "lucide-react";

export function About() {
  const centers = [
    {
      name: "Vikram Sarabhai Space Centre (VSSC)",
      location: "Thiruvananthapuram, Kerala",
      focus: "Launch vehicle development",
    },
    {
      name: "ISRO Satellite Centre (ISAC)",
      location: "Bengaluru, Karnataka",
      focus: "Satellite design and development",
    },
    {
      name: "Satish Dhawan Space Centre (SDSC)",
      location: "Sriharikota, Andhra Pradesh",
      focus: "Launch operations",
    },
    {
      name: "Space Applications Centre (SAC)",
      location: "Ahmedabad, Gujarat",
      focus: "Satellite applications and payloads",
    },
    {
      name: "Liquid Propulsion Systems Centre (LPSC)",
      location: "Thiruvananthapuram, Kerala",
      focus: "Liquid propulsion systems",
    },
    {
      name: "National Remote Sensing Centre (NRSC)",
      location: "Hyderabad, Telangana",
      focus: "Remote sensing applications",
    },
  ];

  const values = [
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Pushing boundaries with cutting-edge space technology",
      color: "bg-yellow-500",
    },
    {
      icon: Target,
      title: "Excellence",
      description: "Striving for the highest standards in all endeavors",
      color: "bg-blue-500",
    },
    {
      icon: Heart,
      title: "Service",
      description: "Dedicated to serving the nation and humanity",
      color: "bg-red-500",
    },
    {
      icon: Users,
      title: "Collaboration",
      description: "Working together with global partners",
      color: "bg-green-500",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section
        className="relative h-96 flex items-center justify-center bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1770370419338-f9a813302baa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBlYXJ0aCUyMG9yYml0fGVufDF8fHx8MTc3MjI5NTIxM3ww&ixlib=rb-4.1.0&q=80&w=1080')`,
        }}
      >
        <div className="text-center max-w-4xl px-4">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">About ISRO</h1>
          <p className="text-xl md:text-2xl text-gray-200">
            India's Gateway to Space Since 1969
          </p>
        </div>
      </section>

      {/* History Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Our History</h2>
              <div className="space-y-4 text-gray-700 leading-relaxed">
                <p>
                  The Indian Space Research Organisation (ISRO) is the national space agency of
                  India, headquartered in Bengaluru. Operating under the Department of Space (DOS),
                  which reports directly to the Prime Minister of India, ISRO is the principal
                  agency for performing tasks related to space-based applications, space
                  exploration, and the development of related technologies.
                </p>
                <p>
                  ISRO was founded in 1969 by Dr. Vikram Sarabhai, widely regarded as the father
                  of the Indian Space Program. Since its inception, ISRO has been committed to
                  utilizing space technology for national development while pursuing space science
                  research and planetary exploration.
                </p>
                <p>
                  From launching its first satellite Aryabhata in 1975 to the historic Chandrayaan-3
                  mission in 2023, ISRO has achieved numerous milestones that have established India
                  as a major spacefaring nation.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <Building2 className="w-10 h-10 text-blue-600 mb-2" />
                  <CardTitle className="text-3xl font-bold text-blue-900">1969</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">Establishment Year</p>
                </CardContent>
              </Card>
              <Card className="bg-green-50 border-green-200">
                <CardHeader>
                  <Rocket className="w-10 h-10 text-green-600 mb-2" />
                  <CardTitle className="text-3xl font-bold text-green-900">129+</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">Successful Missions</p>
                </CardContent>
              </Card>
              <Card className="bg-purple-50 border-purple-200">
                <CardHeader>
                  <Globe className="w-10 h-10 text-purple-600 mb-2" />
                  <CardTitle className="text-3xl font-bold text-purple-900">430+</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">Satellites Launched</p>
                </CardContent>
              </Card>
              <Card className="bg-orange-50 border-orange-200">
                <CardHeader>
                  <Trophy className="w-10 h-10 text-orange-600 mb-2" />
                  <CardTitle className="text-3xl font-bold text-orange-900">17000+</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">Team Members</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-gradient-to-br from-blue-600 to-blue-800 text-white">
              <CardHeader>
                <Target className="w-12 h-12 mb-4" />
                <CardTitle className="text-3xl">Vision</CardTitle>
              </CardHeader>
              <CardContent className="text-blue-100 leading-relaxed">
                <p>
                  To harness space technology for national development while pursuing space science
                  research and planetary exploration. To be among the foremost space agencies in
                  the world, contributing to scientific advancement and societal progress.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-600 to-green-800 text-white">
              <CardHeader>
                <Rocket className="w-12 h-12 mb-4" />
                <CardTitle className="text-3xl">Mission</CardTitle>
              </CardHeader>
              <CardContent className="text-green-100 leading-relaxed">
                <p>
                  To develop space systems and their applications to serve national needs through
                  satellite communications, remote sensing, meteorology, navigation, and space
                  science, while maintaining operational self-reliance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-12 text-center">Our Core Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <Card key={index} className="text-center hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className={`${value.color} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <CardTitle className="text-xl">{value.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600">{value.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Centers */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-4 text-center">ISRO Centers</h2>
          <p className="text-xl text-gray-600 mb-12 text-center">
            Our facilities across India driving space innovation
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {centers.map((center, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start gap-3">
                    <Building2 className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                    <div>
                      <CardTitle className="text-lg mb-2">{center.name}</CardTitle>
                      <p className="text-sm text-gray-600">{center.location}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700">
                    <strong>Focus:</strong> {center.focus}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Banner */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Major Achievements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div>
              <p className="text-lg text-blue-100 mb-2">First to reach Mars</p>
              <p className="text-3xl font-bold">in maiden attempt</p>
            </div>
            <div>
              <p className="text-lg text-blue-100 mb-2">First to land on</p>
              <p className="text-3xl font-bold">lunar south pole</p>
            </div>
            <div>
              <p className="text-lg text-blue-100 mb-2">Record launch of</p>
              <p className="text-3xl font-bold">104 satellites</p>
            </div>
            <div>
              <p className="text-lg text-blue-100 mb-2">Most cost-effective</p>
              <p className="text-3xl font-bold">space missions</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
