import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Textarea } from "../components/ui/textarea";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Mail, Phone, MapPin, Clock, Send, MessageSquare } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    category: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock form submission
    toast.success("Message sent successfully! We'll get back to you soon.");
    setFormData({
      name: "",
      email: "",
      phone: "",
      subject: "",
      category: "",
      message: "",
    });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Headquarters",
      details: [
        "Indian Space Research Organisation",
        "Antariksh Bhavan, New BEL Road",
        "Bengaluru - 560231, Karnataka, India",
      ],
      color: "bg-blue-500",
    },
    {
      icon: Phone,
      title: "Phone",
      details: [
        "Main Office: +91-80-22172294",
        "Public Relations: +91-80-22172336",
        "Fax: +91-80-23412253",
      ],
      color: "bg-green-500",
    },
    {
      icon: Mail,
      title: "Email",
      details: [
        "General Inquiries: contactus@isro.gov.in",
        "Media Relations: pro@isro.gov.in",
        "Technical Support: support@isro.gov.in",
      ],
      color: "bg-purple-500",
    },
    {
      icon: Clock,
      title: "Working Hours",
      details: [
        "Monday - Friday: 9:00 AM - 6:00 PM",
        "Saturday: 9:00 AM - 1:00 PM",
        "Sunday & Holidays: Closed",
      ],
      color: "bg-orange-500",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white py-20 relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 mb-4">
            <MessageSquare className="w-12 h-12" />
            <h1 className="text-5xl font-bold">Contact Us</h1>
          </div>
          <p className="text-xl text-orange-100">
            Get in touch with ISRO - We're here to help
          </p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div
                      className={`${info.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}
                    >
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl">{info.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="text-gray-700 text-sm mb-1">
                        {detail}
                      </p>
                    ))}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Contact Form and Map */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle className="text-2xl">Send us a Message</CardTitle>
                <CardDescription>
                  Fill out the form below and we'll get back to you as soon as possible
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      name="name"
                      placeholder="Enter your full name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="your.email@example.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      placeholder="+91 1234567890"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) =>
                        setFormData({ ...formData, category: value })
                      }
                      required
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Inquiry</SelectItem>
                        <SelectItem value="media">Media & Press</SelectItem>
                        <SelectItem value="academic">Academic Collaboration</SelectItem>
                        <SelectItem value="careers">Careers</SelectItem>
                        <SelectItem value="technical">Technical Support</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject *</Label>
                    <Input
                      id="subject"
                      name="subject"
                      placeholder="Brief subject of your message"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message">Message *</Label>
                    <Textarea
                      id="message"
                      name="message"
                      placeholder="Type your message here..."
                      value={formData.message}
                      onChange={handleChange}
                      required
                      className="w-full min-h-32"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
                    size="lg"
                  >
                    Send Message <Send className="w-4 h-4 ml-2" />
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Quick Links and Additional Info */}
            <div className="space-y-6">
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl">Quick Links</CardTitle>
                  <CardDescription>
                    Find what you're looking for quickly
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4"
                  >
                    <div>
                      <p className="font-semibold text-gray-900">Career Opportunities</p>
                      <p className="text-sm text-gray-600">
                        Join India's premier space organization
                      </p>
                    </div>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4"
                  >
                    <div>
                      <p className="font-semibold text-gray-900">Tenders & Procurement</p>
                      <p className="text-sm text-gray-600">
                        Business opportunities with ISRO
                      </p>
                    </div>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4"
                  >
                    <div>
                      <p className="font-semibold text-gray-900">RTI Information</p>
                      <p className="text-sm text-gray-600">
                        Right to Information requests
                      </p>
                    </div>
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start text-left h-auto py-4"
                  >
                    <div>
                      <p className="font-semibold text-gray-900">Media & Press</p>
                      <p className="text-sm text-gray-600">
                        Resources for journalists
                      </p>
                    </div>
                  </Button>
                </CardContent>
              </Card>

              <Card className="shadow-lg bg-gradient-to-br from-orange-600 via-orange-500 to-orange-600 text-white">
                <CardHeader>
                  <CardTitle className="text-2xl">Visit Us</CardTitle>
                  <CardDescription className="text-orange-100">
                    Plan your visit to ISRO facilities
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-orange-50">
                    ISRO organizes public visits to select facilities. Visitors can witness the
                    marvels of space technology and learn about India's space program.
                  </p>
                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                    <p className="font-semibold mb-2">Visitor Centers:</p>
                    <ul className="space-y-2 text-sm text-orange-50">
                      <li>• Space Expo, Bengaluru</li>
                      <li>• Launch Viewing Gallery, Sriharikota</li>
                      <li>• Museum at Various Centers</li>
                    </ul>
                  </div>
                  <Button className="w-full bg-white text-orange-600 hover:bg-gray-100">
                    Book a Visit
                  </Button>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl">Emergency Contact</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 mb-4">
                    For urgent mission-related or security matters:
                  </p>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <p className="font-bold text-red-900 mb-2">24/7 Emergency Line:</p>
                    <p className="text-2xl font-bold text-red-600">+91-80-2217-2400</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Locate Our Headquarters
          </h2>
          <div className="rounded-xl overflow-hidden shadow-lg">
            <div className="w-full h-96 bg-gray-200 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-blue-600 mx-auto mb-4" />
                <p className="text-xl font-semibold text-gray-900">
                  ISRO Headquarters, Bengaluru
                </p>
                <p className="text-gray-600">Antariksh Bhavan, New BEL Road</p>
                <Button className="mt-4 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700">
                  Open in Google Maps
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}