import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { MissionCard } from "../components/MissionCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";

export function Missions() {
  const completedMissions = [
    {
      title: "Chandrayaan-3",
      description:
        "India's third lunar exploration mission successfully landed on the Moon's south polar region, making India the first country to achieve this feat.",
      status: "Completed" as const,
      date: "August 23, 2023",
      imageUrl:
        "https://images.unsplash.com/photo-1646605381573-e3a846cf6be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb29uJTIwc3VyZmFjZSUyMHNwYWNlfGVufDF8fHx8MTc3MjI5OTM3NHww&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "First nation to land on lunar south pole",
        "Successful rover deployment and operation",
        "Multiple scientific instruments operating successfully",
      ],
    },
    {
      title: "Mars Orbiter Mission (Mangalyaan)",
      description:
        "India's first interplanetary mission to Mars, making ISRO the fourth space agency to reach Mars orbit and the first to do so in its maiden attempt.",
      status: "Completed" as const,
      date: "September 24, 2014",
      imageUrl:
        "https://images.unsplash.com/photo-1711989327933-3f32b36a1f64?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYXJzJTIwcm92ZXIlMjBwbGFuZXR8ZW58MXx8fHwxNzcyMjk5Mzc0fDA&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "First Asian nation to reach Mars orbit",
        "Most cost-effective Mars mission globally",
        "Successfully operated for 8 years",
      ],
    },
    {
      title: "Chandrayaan-1",
      description:
        "India's first lunar probe mission that discovered water molecules on the Moon, revolutionizing our understanding of lunar composition.",
      status: "Completed" as const,
      date: "October 22, 2008",
      imageUrl:
        "https://images.unsplash.com/photo-1646605381573-e3a846cf6be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb29uJTIwc3VyZmFjZSUyMHNwYWNlfGVufDF8fHx8MTc3MjI5OTM3NHww&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "Discovered water on the Moon",
        "Created 3D atlas of the Moon",
        "11 scientific instruments from various countries",
      ],
    },
  ];

  const ongoingMissions = [
    {
      title: "Aditya-L1",
      description:
        "India's first space-based observatory to study the Sun, positioned at Lagrange point L1 to continuously observe solar activities without any eclipses.",
      status: "Ongoing" as const,
      date: "Launched September 2, 2023",
      imageUrl:
        "https://images.unsplash.com/photo-1577565725969-d31af916b4d0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcGFjZSUyMHRlbGVzY29wZSUyMG9ic2VydmF0b3J5fGVufDF8fHx8MTc3MjI5OTM3Nnww&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "Seven payloads for solar observation",
        "Studying solar corona and solar wind",
        "Monitoring space weather",
      ],
    },
    {
      title: "NavIC (Navigation with Indian Constellation)",
      description:
        "India's regional satellite navigation system providing accurate position information service to users in India and the region extending up to 1,500 km.",
      status: "Ongoing" as const,
      date: "Operational since 2018",
      imageUrl:
        "https://images.unsplash.com/photo-1770370419338-f9a813302baa?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBlYXJ0aCUyMG9yYml0fGVufDF8fHx8MTc3MjI5NTIxM3ww&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "Independent navigation system",
        "Better accuracy than GPS in Indian region",
        "Used in various civilian applications",
      ],
    },
  ];

  const plannedMissions = [
    {
      title: "Gaganyaan",
      description:
        "India's first crewed orbital spacecraft mission aimed at demonstrating human spaceflight capability with a three-member crew to Low Earth Orbit.",
      status: "Planned" as const,
      date: "Expected 2025-2026",
      imageUrl:
        "https://images.unsplash.com/photo-1614727187346-ec3a009092b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhc3Ryb25hdXQlMjBzcGFjZXdhbGt8ZW58MXx8fHwxNzcyMjA1OTkyfDA&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "First Indian human spaceflight",
        "Three-member crew mission",
        "7-day orbital mission planned",
      ],
    },
    {
      title: "Chandrayaan-4",
      description:
        "A lunar sample return mission planned to collect samples from the Moon's surface and return them to Earth for detailed scientific analysis.",
      status: "Planned" as const,
      date: "Expected 2027-2028",
      imageUrl:
        "https://images.unsplash.com/photo-1646605381573-e3a846cf6be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb29uJTIwc3VyZmFjZSUyMHNwYWNlfGVufDF8fHx8MTc3MjI5OTM3NHww&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "Sample return mission",
        "Advanced robotic systems",
        "Enhanced scientific payload",
      ],
    },
    {
      title: "Shukrayaan-1",
      description:
        "India's planned mission to Venus to study the planet's atmosphere, surface, and volcanic activity using an orbiter spacecraft.",
      status: "Planned" as const,
      date: "Expected 2028",
      imageUrl:
        "https://images.unsplash.com/photo-1770723965518-72363e66a999?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlYXJ0aCUyMGZyb20lMjBzcGFjZSUyMGJsdWV8ZW58MXx8fHwxNzcyMjk5Mzc2fDA&ixlib=rb-4.1.0&q=80&w=1080",
      achievements: [
        "First Indian Venus mission",
        "Study of Venusian atmosphere",
        "International collaboration",
      ],
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white py-20 relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-bold mb-2">Our Missions</h1>
          <p className="text-lg text-orange-100 mb-4">
            हमारे अभियान - Our Space Endeavors
          </p>
          <p className="text-xl text-orange-100">
            Exploring the cosmos with groundbreaking space missions
          </p>
        </div>
      </section>

      {/* Missions Content */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="completed" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-3 mb-12 h-auto p-1">
              <TabsTrigger value="completed" className="py-3 text-base">
                Completed
              </TabsTrigger>
              <TabsTrigger value="ongoing" className="py-3 text-base">
                Ongoing
              </TabsTrigger>
              <TabsTrigger value="planned" className="py-3 text-base">
                Planned
              </TabsTrigger>
            </TabsList>

            <TabsContent value="completed">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {completedMissions.map((mission, index) => (
                  <MissionCard key={index} {...mission} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="ongoing">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {ongoingMissions.map((mission, index) => (
                  <MissionCard key={index} {...mission} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="planned">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {plannedMissions.map((mission, index) => (
                  <MissionCard key={index} {...mission} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <Footer />
    </div>
  );
}