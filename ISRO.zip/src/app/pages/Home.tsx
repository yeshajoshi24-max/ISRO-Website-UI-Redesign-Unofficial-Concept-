import { Header } from "../components/Header";
import { Footer } from "../components/Footer";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Rocket, Satellite, Globe, Target, ArrowRight, TrendingUp } from "lucide-react";
import { Link } from "react-router";

export function Home() {
  const highlights = [
    {
      title: "Chandrayaan-3",
      description: "Historic lunar south pole landing achievement",
      icon: Rocket,
      color: "bg-gradient-to-br from-orange-500 to-orange-600",
    },
    {
      title: "Gaganyaan",
      description: "India's first human spaceflight program",
      icon: Target,
      color: "bg-gradient-to-br from-blue-600 to-blue-700",
    },
    {
      title: "NavIC",
      description: "Regional navigation satellite system",
      icon: Satellite,
      color: "bg-gradient-to-br from-green-600 to-green-700",
    },
    {
      title: "Mars Orbiter",
      description: "First Asian nation to reach Martian orbit",
      icon: Globe,
      color: "bg-gradient-to-br from-orange-600 to-red-600",
    },
  ];

  const stats = [
    { value: "129+", label: "Successful Missions" },
    { value: "430+", label: "Satellite Launches" },
    { value: "50+", label: "Years of Excellence" },
    { value: "24/7", label: "Mission Control" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <Header />

      {/* Hero Section */}
      <section
        className="relative h-[600px] flex items-center justify-center bg-cover bg-center"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('https://images.unsplash.com/photo-1720214658819-2676e74b4c69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2NrZXQlMjBsYXVuY2glMjBzcGFjZXxlbnwxfHx8fDE3NzIyMzg2NDR8MA&ixlib=rb-4.1.0&q=80&w=1080')`,
        }}
      >
        <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <div className="text-center max-w-4xl px-4">
          <div className="mb-6 inline-block">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="h-1 w-16 bg-orange-500"></div>
              <div className="h-1 w-16 bg-white"></div>
              <div className="h-1 w-16 bg-green-500"></div>
            </div>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4">
            Exploring the Universe
          </h1>
          <p className="text-lg text-orange-300 font-semibold mb-2">
            भारतीय अंतरिक्ष अनुसंधान संगठन
          </p>
          <p className="text-xl md:text-2xl text-gray-200 mb-8">
            India's Gateway to Space - Pioneering Innovation, Inspiring Generations
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/missions">
              <Button size="lg" className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white text-lg px-8 py-6 shadow-xl">
                Explore Missions <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to="/launches">
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 backdrop-blur-sm border-2 border-white text-white hover:bg-white hover:text-orange-600 text-lg px-8 py-6 shadow-xl"
              >
                View Launches
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-12 border-b-4 border-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="flex items-center justify-center mb-2">
                  <TrendingUp className="w-6 h-6 text-orange-600 mr-2 group-hover:scale-110 transition-transform" />
                  <p className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-blue-600 bg-clip-text text-transparent">{stat.value}</p>
                </div>
                <p className="text-gray-600 font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission Highlights */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Mission Highlights</h2>
            <p className="text-xl text-gray-600">
              Discover our groundbreaking achievements in space exploration
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {highlights.map((highlight, index) => {
              const Icon = highlight.icon;
              return (
                <Card key={index} className="hover:shadow-xl transition-all border-2 hover:border-orange-300">
                  <CardHeader>
                    <div className={`${highlight.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4 shadow-lg`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-xl">{highlight.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-700">
                      {highlight.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Featured Mission Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Chandrayaan-3: A Historic Achievement
              </h2>
              <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                On August 23, 2023, ISRO created history by successfully landing Chandrayaan-3
                on the Moon's south polar region. This remarkable achievement made India the
                first nation to land near the lunar south pole and the fourth country to achieve
                a soft landing on the Moon.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <div className="bg-orange-100 rounded-full p-1 mt-1">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-700">
                    First to land on lunar south pole
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-orange-100 rounded-full p-1 mt-1">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-700">
                    Rover successfully exploring the surface
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <div className="bg-orange-100 rounded-full p-1 mt-1">
                    <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                  </div>
                  <span className="text-gray-700">
                    Groundbreaking scientific discoveries
                  </span>
                </li>
              </ul>
              <Link to="/missions">
                <Button size="lg" className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg">
                  Learn More About Our Missions
                </Button>
              </Link>
            </div>
            <div className="rounded-xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1646605381573-e3a846cf6be8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb29uJTIwc3VyZmFjZSUyMHNwYWNlfGVufDF8fHx8MTc3MjI5OTM3NHww&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Lunar Surface"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="text-4xl font-bold mb-4">Join Us in Our Journey</h2>
          <p className="text-xl mb-2 text-orange-100">
            सत्यमेव जयते - Truth Alone Triumphs
          </p>
          <p className="text-lg mb-8 text-orange-100">
            Be part of India's space exploration story
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/about">
              <Button
                size="lg"
                className="bg-white text-orange-600 hover:bg-gray-100 shadow-lg"
              >
                About ISRO
              </Button>
            </Link>
            <Link to="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white hover:text-orange-600 shadow-lg"
              >
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}