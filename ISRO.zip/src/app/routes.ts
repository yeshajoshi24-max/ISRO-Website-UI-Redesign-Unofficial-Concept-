import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Missions } from "./pages/Missions";
import { Launches } from "./pages/Launches";
import { About } from "./pages/About";
import { Contact } from "./pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/missions",
    Component: Missions,
  },
  {
    path: "/launches",
    Component: Launches,
  },
  {
    path: "/about",
    Component: About,
  },
  {
    path: "/contact",
    Component: Contact,
  },
]);
