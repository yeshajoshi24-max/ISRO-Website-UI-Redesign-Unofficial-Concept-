import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ArrowRight } from "lucide-react";

interface MissionCardProps {
  title: string;
  description: string;
  status: "Completed" | "Ongoing" | "Planned";
  date: string;
  imageUrl: string;
  achievements?: string[];
}

export function MissionCard({
  title,
  description,
  status,
  date,
  imageUrl,
  achievements,
}: MissionCardProps) {
  const statusColors = {
    Completed: "bg-green-100 text-green-800 border-green-300",
    Ongoing: "bg-orange-100 text-orange-800 border-orange-300",
    Planned: "bg-blue-100 text-blue-800 border-blue-300",
  };

  return (
    <Card className="overflow-hidden hover:shadow-xl transition-all border-2 hover:border-orange-300">
      <div className="aspect-video w-full overflow-hidden relative">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
        />
      </div>
      <CardHeader>
        <div className="flex justify-between items-start gap-2 mb-2">
          <CardTitle className="text-xl">{title}</CardTitle>
          <Badge className={statusColors[status]}>{status}</Badge>
        </div>
        <CardDescription className="text-sm text-gray-600">{date}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700 mb-4">{description}</p>
        {achievements && achievements.length > 0 && (
          <div className="mb-4">
            <p className="font-semibold text-sm text-gray-900 mb-2">Key Achievements:</p>
            <ul className="text-sm text-gray-700 space-y-1">
              {achievements.map((achievement, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="text-orange-600 mt-1">•</span>
                  <span>{achievement}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        <Button className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white">
          Learn More <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
}