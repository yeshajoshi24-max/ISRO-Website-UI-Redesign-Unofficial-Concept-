import { Mail, Phone, MapPin, Facebook, Twitter, Youtube, Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gradient-to-b from-gray-900 via-blue-900 to-gray-900 text-gray-300 border-t-4 border-orange-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* About Section */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="relative w-12 h-12">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                  <circle cx="50" cy="50" r="48" fill="#FF6B35" />
                  <circle cx="50" cy="50" r="42" fill="white" />
                  <circle cx="50" cy="50" r="35" fill="#1E40AF" />
                  <ellipse cx="50" cy="50" rx="28" ry="15" fill="none" stroke="white" strokeWidth="1.5" />
                  <ellipse cx="50" cy="50" rx="15" ry="28" fill="none" stroke="white" strokeWidth="1.5" />
                  <circle cx="50" cy="50" r="4" fill="white" />
                  <circle cx="50" cy="22" r="2.5" fill="#FF6B35" />
                  <circle cx="78" cy="50" r="2.5" fill="#FF6B35" />
                  <circle cx="50" cy="78" r="2.5" fill="#FF6B35" />
                  <circle cx="22" cy="50" r="2.5" fill="#FF6B35" />
                </svg>
              </div>
              <h3 className="text-white font-bold text-lg">ISRO</h3>
            </div>
            <p className="text-sm leading-relaxed">
              Indian Space Research Organisation is the national space agency of India,
              headquartered in Bengaluru. ISRO is responsible for space-based operations,
              space exploration, and the development of related technologies.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4 border-b-2 border-orange-500 pb-2 inline-block">
              Quick Links
            </h3>
            <ul className="space-y-2 text-sm mt-4">
              <li>
                <a href="#" className="hover:text-orange-400 transition-colors">
                  Careers
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-400 transition-colors">
                  Tenders
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-400 transition-colors">
                  RTI
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-400 transition-colors">
                  Publications
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-orange-400 transition-colors">
                  Photo Gallery
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4 border-b-2 border-orange-500 pb-2 inline-block">
              Contact Us
            </h3>
            <ul className="space-y-3 text-sm mt-4">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-1 flex-shrink-0 text-orange-400" />
                <span>
                  Antariksh Bhavan, New BEL Road,
                  <br />
                  Bengaluru - 560231, India
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 flex-shrink-0 text-orange-400" />
                <span>+91-80-22172294</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 flex-shrink-0 text-orange-400" />
                <span>contactus@isro.gov.in</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4 border-b-2 border-orange-500 pb-2 inline-block">
              Follow Us
            </h3>
            <div className="flex gap-3 mt-4">
              <a
                href="#"
                className="bg-gradient-to-br from-blue-600 to-blue-800 p-3 rounded-lg hover:from-orange-500 hover:to-orange-600 transition-all transform hover:scale-110"
                aria-label="Facebook"
              >
                <Facebook className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-gradient-to-br from-blue-600 to-blue-800 p-3 rounded-lg hover:from-orange-500 hover:to-orange-600 transition-all transform hover:scale-110"
                aria-label="Twitter"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-gradient-to-br from-blue-600 to-blue-800 p-3 rounded-lg hover:from-orange-500 hover:to-orange-600 transition-all transform hover:scale-110"
                aria-label="YouTube"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="bg-gradient-to-br from-blue-600 to-blue-800 p-3 rounded-lg hover:from-orange-500 hover:to-orange-600 transition-all transform hover:scale-110"
                aria-label="Instagram"
              >
                <Instagram className="w-5 h-5" />
              </a>
            </div>
            <p className="text-sm mt-4">
              Stay updated with our latest missions and achievements.
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 mt-8 pt-8 text-sm">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="h-1 w-12 bg-orange-500"></div>
              <div className="h-1 w-12 bg-white"></div>
              <div className="h-1 w-12 bg-green-500"></div>
            </div>
            <p className="text-center">
              © 2026 Indian Space Research Organisation (ISRO). All rights reserved.
            </p>
            <div className="flex justify-center gap-4">
              <a href="#" className="hover:text-orange-400 transition-colors">
                Privacy Policy
              </a>
              <span>|</span>
              <a href="#" className="hover:text-orange-400 transition-colors">
                Terms of Use
              </a>
              <span>|</span>
              <a href="#" className="hover:text-orange-400 transition-colors">
                Disclaimer
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}