import { Link, useLocation } from "react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

export function Header() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { path: "/", label: "Home" },
    { path: "/missions", label: "Missions" },
    { path: "/launches", label: "Launches" },
    { path: "/about", label: "About" },
    { path: "/contact", label: "Contact" },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="sticky top-0 z-50 bg-white border-b-4 border-orange-500 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-4 group">
            {/* ISRO Logo */}
            <div className="relative w-16 h-16 flex-shrink-0">
              <svg viewBox="0 0 100 100" className="w-full h-full">
                {/* Outer orange circle */}
                <circle cx="50" cy="50" r="48" fill="#FF6B35" />
                {/* Inner white circle */}
                <circle cx="50" cy="50" r="42" fill="white" />
                {/* Blue center circle */}
                <circle cx="50" cy="50" r="35" fill="#1E40AF" />
                {/* Satellite orbit lines */}
                <ellipse cx="50" cy="50" rx="28" ry="15" fill="none" stroke="white" strokeWidth="1.5" />
                <ellipse cx="50" cy="50" rx="15" ry="28" fill="none" stroke="white" strokeWidth="1.5" />
                {/* Center dot (satellite) */}
                <circle cx="50" cy="50" r="4" fill="white" />
                {/* Orbital dots */}
                <circle cx="50" cy="22" r="2.5" fill="#FF6B35" />
                <circle cx="78" cy="50" r="2.5" fill="#FF6B35" />
                <circle cx="50" cy="78" r="2.5" fill="#FF6B35" />
                <circle cx="22" cy="50" r="2.5" fill="#FF6B35" />
              </svg>
            </div>
            <div>
              <h1 className="font-bold text-2xl bg-gradient-to-r from-orange-600 to-blue-600 bg-clip-text text-transparent">
                ISRO
              </h1>
              <p className="text-xs text-gray-700 font-medium">
                भारतीय अंतरिक्ष अनुसंधान संगठन
              </p>
              <p className="text-xs text-gray-600">Indian Space Research Organisation</p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-2">
            {navItems.map((item) => (
              <Link key={item.path} to={item.path}>
                <Button
                  variant={isActive(item.path) ? "default" : "ghost"}
                  className={`font-semibold ${
                    isActive(item.path)
                      ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700"
                      : "text-gray-700 hover:bg-orange-50 hover:text-orange-600"
                  }`}
                >
                  {item.label}
                </Button>
              </Link>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-orange-50 transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-orange-600" />
            ) : (
              <Menu className="w-6 h-6 text-orange-600" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-orange-200">
            <div className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <Button
                    variant={isActive(item.path) ? "default" : "ghost"}
                    className={`w-full justify-start font-semibold ${
                      isActive(item.path)
                        ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700"
                        : "text-gray-700 hover:bg-orange-50 hover:text-orange-600"
                    }`}
                  >
                    {item.label}
                  </Button>
                </Link>
              ))}
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}