import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Calendar, MapPin, Rocket } from "lucide-react";

interface LaunchCardProps {
  vehicle: string;
  mission: string;
  date: string;
  location: string;
  status: "Success" | "Scheduled" | "Failed";
  payload: string;
}

export function LaunchCard({
  vehicle,
  mission,
  date,
  location,
  status,
  payload,
}: LaunchCardProps) {
  const statusColors = {
    Success: "bg-green-100 text-green-800 border-green-300",
    Scheduled: "bg-orange-100 text-orange-800 border-orange-300",
    Failed: "bg-red-100 text-red-800 border-red-300",
  };

  return (
    <Card className="hover:shadow-xl transition-all border-2 hover:border-orange-300">
      <div className="h-1 bg-gradient-to-r from-orange-500 via-white to-green-500"></div>
      <CardHeader>
        <div className="flex justify-between items-start gap-2 mb-2">
          <CardTitle className="text-lg">{vehicle}</CardTitle>
          <Badge className={statusColors[status]}>{status}</Badge>
        </div>
        <CardDescription className="font-medium text-gray-900">{mission}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-gray-700">
          <Calendar className="w-4 h-4 text-orange-600" />
          <span>{date}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-700">
          <MapPin className="w-4 h-4 text-orange-600" />
          <span>{location}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-gray-700">
          <Rocket className="w-4 h-4 text-orange-600" />
          <span>{payload}</span>
        </div>
        <Button variant="outline" className="w-full mt-4 border-2 border-orange-500 text-orange-600 hover:bg-orange-50">
          View Details
        </Button>
      </CardContent>
    </Card>
  );
}